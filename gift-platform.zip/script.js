document.addEventListener("DOMContentLoaded", () => {
  // ダミーデータ
  const gifts = ["感謝", "共感", "励まし"];
  const themes = ["最近嬉しかったこと", "小さな挑戦", "今の気持ち"];

  // ランダム表示
  document.getElementById("gift-text").textContent = gifts[Math.floor(Math.random() * gifts.length)];
  document.getElementById("theme-text").textContent = themes[Math.floor(Math.random() * themes.length)];

  // フィードバック送信
  const feedbackForm = document.getElementById("feedbackForm");
  const feedbackMsg = document.getElementById("feedback-message");

  feedbackForm.addEventListener("submit", (e) => {
    e.preventDefault();
    feedbackMsg.textContent = "フィードバックありがとうございます！";
    feedbackForm.reset();
  });
});
